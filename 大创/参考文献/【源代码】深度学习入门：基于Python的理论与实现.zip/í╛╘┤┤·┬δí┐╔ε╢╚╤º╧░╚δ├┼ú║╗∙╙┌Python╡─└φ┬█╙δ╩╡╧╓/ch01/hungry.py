print("I'm hungry!")
